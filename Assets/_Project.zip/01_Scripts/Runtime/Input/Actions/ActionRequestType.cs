namespace Project.InputSystem
{
    public enum ActionRequestType
    {
        OpenActionMenu,
        PlayCard
    }
}