﻿namespace Project.InputSystem
{
    public enum ActionTargetType
    {
        Tile,
        Meld,
        Card // ✅ 추가
    }
}