namespace System.Runtime.CompilerServices
{
    internal sealed class IsExternalInit { }
}