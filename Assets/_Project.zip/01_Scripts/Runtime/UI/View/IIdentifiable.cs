namespace Project.UI
{
    public interface IIdentifiable
    {
        int Id { get; }
    }
}