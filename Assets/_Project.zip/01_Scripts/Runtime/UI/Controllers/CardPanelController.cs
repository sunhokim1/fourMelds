using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using FourMelds.Cards;

public sealed class CardPanelController : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private GameObject panelRoot;
    [SerializeField] private Transform contentRoot;
    [SerializeField] private Button buttonPrefab;
    [SerializeField] private HandTilesView handTilesView;


    [Header("Source")]
    [SerializeField] private ActionMenuController actionMenuController; // TurnState ����(������ �ڵ� Ž��)

    private readonly List<Button> _spawned = new();

    private void Start()
    {
        if (actionMenuController == null)
            actionMenuController = FindFirstObjectByType<ActionMenuController>();

        if (actionMenuController == null)
        {
            Debug.LogError("[CardPanel] ActionMenuController not found (TurnState source missing).");
            enabled = false;
            return;
        }

        if (handTilesView == null)
            handTilesView = FindFirstObjectByType<HandTilesView>();


        Render();
    }

    public void Render()
    {
        Clear();

        if (panelRoot == null || contentRoot == null || buttonPrefab == null)
        {
            Debug.LogError("[CardPanel] UI refs are null (Inspector?)");
            return;
        }

        panelRoot.SetActive(true);

        var cards = CardRegistry.DefaultCards;

        for (int i = 0; i < cards.Count; i++)
        {
            int idx = i;
            var card = cards[idx];

            var btn = Instantiate(buttonPrefab, contentRoot);
            _spawned.Add(btn);

            // ��ư �ؽ�Ʈ �ٲٱ� (������ �ȿ� Text�� �ִٰ� ����)
            var text = btn.GetComponentInChildren<Text>(true);
            if (text != null)
                text.text = card != null ? card.Name : $"Card {idx}";

            btn.onClick.AddListener(() =>
            {
                var state = actionMenuController.TurnState;
                if (state == null)
                {
                    Debug.LogWarning("[CardPanel] TurnState is null");
                    return;
                }

                if (CardPlayService.TryPlay(idx, state, out var reason))
                {
                    Debug.Log($"[CARD] Played idx={idx} ({card?.Id})");
                    Debug.Log($"[HAND] {string.Join(",", state.HandTiles)}");
                    if (handTilesView != null)
                        handTilesView.Render(state.HandTiles);

                }
                else
                {
                    Debug.LogWarning($"[CARD] Fail idx={idx} reason={reason}");
                }
            });
        }
    }

    private void Clear()
    {
        for (int i = 0; i < _spawned.Count; i++)
        {
            var b = _spawned[i];
            if (b != null) Destroy(b.gameObject);
        }
        _spawned.Clear();
    }
}
