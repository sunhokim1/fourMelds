﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Project.UI.Models;

public class ActionMenuView : MonoBehaviour
{
    [SerializeField] private GameObject panelRoot;
    [SerializeField] private Transform contentRoot;
    [SerializeField] private Button buttonPrefab;

    public event Action<ActionOption> OnOptionSelected;

    private readonly List<Button> _spawned = new();

    public void Show(ActionMenuModel model)
    {
        Clear();

        if (panelRoot == null)
        {
            Debug.LogError("[ActionMenuView] panelRoot is null (Inspector?)");
            return;
        }
        if (contentRoot == null)
        {
            Debug.LogError("[ActionMenuView] contentRoot is null (Inspector?)");
            return;
        }
        if (buttonPrefab == null)
        {
            Debug.LogError("[ActionMenuView] buttonPrefab is null (Inspector?)");
            return;
        }
        if (model == null || model.Options == null)
        {
            Debug.LogError("[ActionMenuView] model or model.Options is null");
            return;
        }

        panelRoot.SetActive(true);

        foreach (var option in model.Options)
        {
            var btn = Instantiate(buttonPrefab, contentRoot);
            _spawned.Add(btn);

            // ✅ null-safe
            var tiles = option.PreviewTiles ?? Array.Empty<int>();

            var previews = btn.GetComponentsInChildren<Text>(true);

            foreach (var p in previews)
                p.gameObject.SetActive(false);

            for (int i = 0; i < tiles.Length && i < previews.Length; i++)
            {
                previews[i].gameObject.SetActive(true);
                previews[i].text = (tiles[i] % 100).ToString();
            }

            btn.onClick.AddListener(() =>
            {
                OnOptionSelected?.Invoke(option);
                Hide();
            });
        }
    }

    public void Hide()
    {
        if (panelRoot != null)
            panelRoot.SetActive(false);

        Clear();
    }

    private void Clear()
    {
        foreach (var b in _spawned)
            if (b != null) Destroy(b.gameObject);

        _spawned.Clear();
    }
}
