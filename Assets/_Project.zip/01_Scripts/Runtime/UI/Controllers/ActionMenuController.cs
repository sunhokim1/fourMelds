﻿using UnityEngine;
using Project.InputSystem;
using Project.Core.Turn;
using Project.Core.Action.Query;
using Project.Core.Action.Execute;
using Project.UI.Models;
using System.Linq;
using FourMelds.Core.Turn;

public class ActionMenuController : MonoBehaviour, IActionRequestSink
{
    [SerializeField] private MouseActionRequestSource inputSource;
    [SerializeField] private ActionMenuView menuView;
    [SerializeField] private MeldSlotsView meldSlotsView;
    [SerializeField] private HandTilesView handTilesView;


    private TurnState _turnState;
    private IActionExecutionService _execService;
    private IActionQueryService _queryService;

    public TurnState TurnState => _turnState;

    private void Awake()
    {


        // ✅ 카드 옵션을 뱉는 Query / 카드 실행을 처리하는 Exec로 교체
        _queryService = new DummyActionQueryService();
        _execService = new DummyActionExecutionService();

        // TurnLoopController가 Start에서 TurnState를 링크하니까,
        // 여기 임시 타일은 “초기 테스트용”으로만 존재.
        _turnState = new TurnState(System.Array.Empty<int>());

    }

    private void Start()
    {
        if (meldSlotsView != null)
            meldSlotsView.Render(_turnState.Melds);

        if (handTilesView != null)
            handTilesView.Render(_turnState.HandTiles);
    }


    private void OnEnable()
    {
        inputSource.OnRequest += Handle;
        menuView.OnOptionSelected += OnOptionSelected;
    }

    private void OnDisable()
    {
        inputSource.OnRequest -= Handle;
        menuView.OnOptionSelected -= OnOptionSelected;
    }

    public void Handle(ActionRequest request)
    {
        var snapshot = new TurnSnapshot(
            phase: _turnState.Phase,
            turnIndex: _turnState.TurnIndex,
            handTiles: _turnState.HandTiles,
            meldIds: _turnState.Melds.Select(m => m.MeldId).ToArray()
        );

        var menu = _queryService.Query(request, snapshot);

        if (menu.Options.Count == 0)
        {
            menuView.Hide();
            return;
        }

        menuView.Show(menu);
    }

    private void OnOptionSelected(ActionOption option)
    {
        // option.Payload로 cardId 같은 값 전달 가능
        var cmd = new ActionCommand(option.Command, targetId: 0, payload: option.Payload);

        if (_execService.Execute(cmd, _turnState, out var reason))
        {
            Debug.Log($"[EXEC] Success: {cmd}");
            Debug.Log($"[HAND] {string.Join(",", _turnState.HandTiles)}");

            var meldText = string.Join(" | ",
                _turnState.Melds.Select(m =>
                    $"{m.MeldId}:{m.Type}({string.Join(",", m.Tiles)}) fixed={m.IsFixed}"
                )
            );
            Debug.Log($"[MELDS] {meldText}");

            if (meldSlotsView != null)
                meldSlotsView.Render(_turnState.Melds);

            if (handTilesView != null)
                handTilesView.Render(_turnState.HandTiles);

        }
        else
        {
            Debug.LogWarning($"[EXEC] Fail: {cmd} reason={reason}");
        }
    }
}
