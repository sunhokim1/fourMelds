﻿using System.Collections.Generic;
using UnityEngine;

public sealed class HandTilesView : MonoBehaviour
{
    [SerializeField] private Transform contentRoot;   // 타일들이 들어갈 부모
    [SerializeField] private TileView tilePrefab;     // TileView 프리팹(타일 클릭/우클릭 이벤트 포함)

    private readonly List<TileView> _spawned = new();

    public void Render(IReadOnlyList<int> handTiles)
    {
        Clear();

        if (contentRoot == null)
        {
            Debug.LogError("[HandTilesView] contentRoot is null (Inspector?)");
            return;
        }
        if (tilePrefab == null)
        {
            Debug.LogError("[HandTilesView] tilePrefab is null (Inspector?)");
            return;
        }
        if (handTiles == null) handTiles = System.Array.Empty<int>();

        for (int i = 0; i < handTiles.Count; i++)
        {
            int tileId = handTiles[i];

            var tv = Instantiate(tilePrefab, contentRoot);
            _spawned.Add(tv);

            // TileView가 이미 "타일 ID를 받아서 표시 + 우클릭 입력을 Raise"하는 구조라면
            // SetTileId/Bind 같은 함수명이 프로젝트마다 다름.
            // 아래 2줄 중 네 TileView에 있는 걸로 하나만 맞춰서 쓰면 됨.

            // ✅ (A) 가장 흔한 방식: tv.SetTileId(tileId);
            // ✅ (B) 또는 tv.Bind(tileId);

            // ---- 여기서부터: 네 TileView API에 맞게 1줄만 고쳐줘 ----
            tv.SetTileId(tileId);
            // --------------------------------------------------------
        }
    }

    private void Clear()
    {
        for (int i = 0; i < _spawned.Count; i++)
        {
            if (_spawned[i] != null)
                Destroy(_spawned[i].gameObject);
        }
        _spawned.Clear();
    }
}
