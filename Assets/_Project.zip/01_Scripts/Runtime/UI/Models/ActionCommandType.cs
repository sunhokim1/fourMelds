﻿namespace Project.UI.Models
{
    public enum ActionCommandType
    {
        CreateShuntsu,
        CreateKoutsu,
        PromoteToKan,
        PlayCard // ✅ 추가
    }

}