// Assets/_Project/01_Scripts/Runtime/Core/Suits/MahjongSuit.cs

namespace FourMelds.Core.Suits
{
    public enum MahjongSuit
    {
        Manzu,
        Souzu,
        Pinzu,   // ���
        Honor
    }
}
