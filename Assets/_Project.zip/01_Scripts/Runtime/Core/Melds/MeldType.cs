namespace Project.Core.Melds
{
    public enum MeldType
    {
        Shuntsu,
        Koutsu,
        Kantsu
    }
}