// Assets/_Project/01_Scripts/Runtime/Core/Turn/TurnPhase.cs

namespace FourMelds.Core.Turn
{
   public enum TurnPhase
   {
       Draw,
       Build,
       Resolve,
       Enemy,
       Cleanup
   }

}
