// Assets/_Project/01_Scripts/Runtime/Core/Turn/TurnState.cs

using System;
using System.Collections.Generic;
using FourMelds.Core.Turn;
using Project.Core.Melds;
using Project.Core.Tiles;

namespace Project.Core.Turn
{
    public class TurnState
    {
        private readonly List<int> _handTiles;
        private readonly List<MeldState> _melds = new();
        private int _nextMeldId = 1;

        // Day4: ������ Draw�� ����δ� �� ��� (TurnLoopController.Start()������ SetPhase(Draw) ��)
        public TurnPhase Phase { get; private set; } = TurnPhase.Draw;
        public int TurnIndex { get; private set; } = 1;

        public IReadOnlyList<int> HandTiles => _handTiles;
        public IReadOnlyList<MeldState> Melds => _melds;

        // Head�� "����"�� �ƴ϶� ���� ���� (A��)
        public int HeadTileId { get; private set; } = 0; // 0�̸� ���� ����

        // TilePool�� TurnLoopController(���� ����)�� ����� TurnState�� �����Ѵ�.
        public TilePool Pool { get; private set; }

        public TurnState(IEnumerable<int> initialTiles)
        {
            _handTiles = new List<int>(initialTiles);
        }

        public void SetPhase(TurnPhase phase) => Phase = phase;

        public void SetPool(TilePool pool)
        {
            Pool = pool ?? throw new ArgumentNullException(nameof(pool));
        }

        public void SetHeadTile(int tileId)
        {
            if (tileId == 0) throw new ArgumentException("Head tileId cannot be 0.", nameof(tileId));
            HeadTileId = tileId;
        }

        public void ClearHead() => HeadTileId = 0;

        public void AddHandTile(int tileId) => _handTiles.Add(tileId);

        public void AdvanceTurn()
        {
            TurnIndex++;
            Phase = TurnPhase.Draw;
        }

        /// <summary>
        /// ��: �� ���� �� ����/���� �Ҹ�.
        /// Pool ����/Head ��ο�/�ʱ� ���� ��ο�� "�� ����(Draw)"���� �ܺΰ� ó���Ѵ�.
        /// </summary>
        public void CleanupForNextTurn()
        {
            // 0) �̹� �� �Ҹ�(��Ģ)
            ClearAllHandTiles();
            ClearAllMelds(resetMeldId: true);

            // 1) Head �ʱ�ȭ (���� �� Draw���� �ٽ� ����)
            HeadTileId = 0;

            // 2) �� ����
            AdvanceTurn(); // TurnIndex++ / Phase=Draw
        }

        public int CreateMeld(MeldType type, int[] tiles, bool fixedNow = false)
        {
            var meld = new MeldState(_nextMeldId++, type, tiles, fixedNow);
            _melds.Add(meld);
            return meld.MeldId;
        }

        public bool TryRemoveTile(int tileId)
        {
            int idx = _handTiles.IndexOf(tileId);
            if (idx < 0) return false;
            _handTiles.RemoveAt(idx);
            return true;
        }

        public int CountOf(int tileId)
        {
            int c = 0;
            for (int i = 0; i < _handTiles.Count; i++)
                if (_handTiles[i] == tileId) c++;
            return c;
        }

        // --- �� ������ (��: �� ������ ���� �Ҹ�) ---

        public void ClearAllHandTiles() => _handTiles.Clear();

        public void ClearAllMelds(bool resetMeldId = true)
        {
            _melds.Clear();
            if (resetMeldId) _nextMeldId = 1;
        }

        public void Dev_SetHandTiles(IEnumerable<int> tiles)
        {
            _handTiles.Clear();
            _handTiles.AddRange(tiles);
        }

        public void Dev_AddMeld(MeldType type, int[] tiles, bool fixedNow)
        {
            CreateMeld(type, tiles, fixedNow);
        }

        public void Dev_SetMelds(params (MeldType type, bool fixedNow, int[] tiles)[] melds)
        {
            ClearAllMelds(resetMeldId: true);

            for (int i = 0; i < melds.Length; i++)
            {
                var m = melds[i];
                CreateMeld(m.type, m.tiles, m.fixedNow);
            }
        }
    }
}
