﻿// Assets/_Project/01_Scripts/Runtime/Combat/TurnLoopController.cs

using System;
using UnityEngine;
using FourMelds.Combat.TurnIntegration;
using FourMelds.Core.Turn;
using Project.Core.Turn;
using Project.Core.Melds;
using Project.Core.Tiles;

namespace FourMelds.Combat
{
    public sealed class TurnLoopController : MonoBehaviour
    {
        [SerializeField] private ActionMenuController _actionMenu;
        [SerializeField] private int _playerHp = 50;
        [SerializeField] private int _enemyHp = 60;

        // 카드 시스템 전까지 임시 시작 손패 수
        [SerializeField] private int _initialHandSize = 8;

        private TurnState _turnState;
        private CombatState _combatState;

        private TurnAttackContextBuilder _builder;
        private TurnEndAttackExecutor _executor;
        private AttackResultApplier _applier;

        // 전투 단위 TilePool (전투 내내 유지)
        private TilePool _tilePool;

        private void Awake()
        {
            _combatState = new CombatState(_playerHp, _enemyHp);

            _builder = new TurnAttackContextBuilder();
            _executor = new TurnEndAttackExecutor(CreatePipeline());
            _applier = new AttackResultApplier();
        }

        private void Start()
        {
            if (_actionMenu == null)
                _actionMenu = FindFirstObjectByType<ActionMenuController>();

            if (_actionMenu == null)
            {
                Debug.LogError("[TURN] ActionMenuController not found in scene.");
                enabled = false;
                return;
            }

            _turnState = _actionMenu.TurnState;

            if (_turnState == null)
            {
                Debug.LogError("[TURN] ActionMenuController.TurnState is null. (Awake order?)");
                enabled = false;
                return;
            }

            // 전투 단위 풀 생성 + TurnState에 주입
            _tilePool = new TilePool(TileCatalog.AllTileIds, copiesPerTile: 4);
            _turnState.SetPool(_tilePool);

            Debug.Log("[TURN] TurnState linked.");
            Debug.Log("[TURN] TilePool created (combat-scoped).");

            // (선택) Day6 테스트 멜드 세팅 유지
            Dev_Test_ToitoiSanankou();

            // Day4: 턴 시작 트리거
            _turnState.SetPhase(TurnPhase.Draw);
            Advance();
        }

        // UI 버튼(= Build 완료)에서 호출
        public void OnClick_BuildDone()
        {
            if (_turnState == null)
            {
                Debug.LogError("[TURN] TurnState is null. Did Start() run?");
                return;
            }

            // "지금 상태는 Build다. Build에서 해야 할 다음 행동(ResolvePlayer)을 실행해라"
            _turnState.SetPhase(TurnPhase.Build);
            Advance();
        }

        private DamagePipeline CreatePipeline()
        {
            return new DamagePipeline(new IDamageStep[]
            {
                new BaseDamageStep(),
                new YakuStep(),
                new ClampStep() // 아주 큰 값만 컷
            });
        }

        private void Advance()
        {
            switch (_turnState.Phase)
            {
                case TurnPhase.Draw:
                    EnterBuildFromDraw();
                    break;

                case TurnPhase.Build:
                    ResolvePlayer();
                    break;

                case TurnPhase.Resolve:
                    EnterEnemy();
                    break;

                case TurnPhase.Enemy:
                    RunEnemy();
                    break;

                case TurnPhase.Cleanup:
                    StartNextTurn();
                    break;
            }
        }

        /// <summary>
        /// Draw 단계에서 "턴 시작 처리"를 하고 Build로 들어간다.
        /// - Head 1장 자동 지급(손패에 넣지 않음)
        /// - 카드 시스템 전까지 임시 시작 손패 드로우
        /// </summary>
        private void EnterBuildFromDraw()
        {
            if (_tilePool == null)
                throw new InvalidOperationException("TilePool is null. Did Start() run?");

            // 1) 턴 시작마다 Head 1장 (A안: 별도 슬롯)
            if (!_tilePool.TryDrawRandom(_ => true, out var head))
                throw new InvalidOperationException("TilePool exhausted - cannot draw Head.");

            _turnState.SetHeadTile(head);

            // 2) 카드 시스템 전까지 임시 시작 손패
            //    (룰: '턴 종료 시 손패 소멸'이므로, 매 턴 새로 뽑아야 플레이가 됨)
            for (int i = 0; i < _initialHandSize; i++)
            {
                if (!_tilePool.TryDrawRandom(_ => true, out var t))
                    break;

                _turnState.AddHandTile(t);
            }

            _turnState.SetPhase(TurnPhase.Build);

            Debug.Log($"[TURN] Enter Build. Turn={_turnState.TurnIndex}, Head={_turnState.HeadTileId}, PlayerHP={_combatState.PlayerHP}, EnemyHP={_combatState.EnemyHP}");
        }

        private void ResolvePlayer()
        {
            _turnState.SetPhase(TurnPhase.Resolve);

            Debug.Log($"[TURN] BuildDone -> Resolve. EnemyHP(before)={_combatState.EnemyHP}");

            var ctx = _builder.Build(_turnState, _combatState);
            var result = _executor.Execute(ctx);
            _applier.Apply(_combatState, result);

            if (result.LogEntries != null && result.LogEntries.Count > 0)
            {
                for (int i = 0; i < result.LogEntries.Count; i++)
                {
                    var l = result.LogEntries[i];
                    Debug.Log($"[DMGLOG] {l.StepId}: {l.BeforeDamage} -> {l.AfterDamage} ({l.Reason})");
                }
            }

            Debug.Log($"[TURN] Resolve done. Damage={result.FinalDamage}, EnemyHP(after)={_combatState.EnemyHP}");

            Advance(); // Resolve -> Enemy
        }

        private void EnterEnemy()
        {
            _turnState.SetPhase(TurnPhase.Enemy);
            Advance(); // Day4: 적 턴은 자동 진행
        }

        private void RunEnemy()
        {
            // Day4 최소 구현: 고정 데미지 1
            const int dmg = 1;
            _combatState.ApplyPlayerDamage(dmg);

            Debug.Log($"[TURN] EnemyAct. Damage={dmg}, PlayerHP(after)={_combatState.PlayerHP}");

            _turnState.SetPhase(TurnPhase.Cleanup);
            Advance();
        }

        private void StartNextTurn()
        {
            _turnState.CleanupForNextTurn();

            Debug.Log($"[TURN] Cleanup -> NextTurn. Turn={_turnState.TurnIndex}");

            Advance(); // -> Draw
        }

        public void Dev_Setup_ToitoiSanankou()
        {
            _turnState.ClearAllHandTiles();
            _turnState.ClearAllMelds();

            // 예: 커쯔 3개 + 아무 몸통 1개
            _turnState.Dev_AddMeld(MeldType.Koutsu, new[] { 101, 101, 101 }, fixedNow: false); // 앙커로 취급
            _turnState.Dev_AddMeld(MeldType.Koutsu, new[] { 102, 102, 102 }, fixedNow: false);
            _turnState.Dev_AddMeld(MeldType.Koutsu, new[] { 103, 103, 103 }, fixedNow: false);
            _turnState.Dev_AddMeld(MeldType.Koutsu, new[] { 201, 201, 201 }, fixedNow: true);  // 밍커로 취급(고정)

            Debug.Log("[DEV] Setup Toitoi + Sanankou");
        }

        public void Dev_Test_ToitoiSanankou()
        {
            if (_turnState == null) return;

            _turnState.Dev_SetMelds(
                (MeldType.Koutsu, false, new[] { 102, 102, 102 }),
                (MeldType.Koutsu, false, new[] { 103, 103, 103 }),
                (MeldType.Koutsu, false, new[] { 104, 104, 104 }),
                (MeldType.Koutsu, true, new[] { 202, 202, 202 })
            );

            Debug.Log("[DEV] Melds set: Toitoi + Sanankou expected");
        }
    }
}
