using System;

namespace FourMelds.Combat
{
    public static class YakuRegistry
    {
        // ������ �ϵ��ڵ� (Day8 ���� SO/�����ͷ� ��ü)
        public static IYakuEffect[] CreateDefault()
        {
            return new IYakuEffect[]
            {
                new Yaku_Tanyao(),
                new Yaku_Toitoi(),
                new Yaku_Sanankou(),
                new Yaku_Suankou()
            };
        }
    }
}
