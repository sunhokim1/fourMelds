namespace FourMelds.Combat
{
    public enum SideEffectType
    {
        HealPlayer,
        AddArmorPlayer,
        ApplyDebuffEnemy,
        DrawCardsNextTurn,
        SpawnTilesNextTurn,
        GainTileImmediate
    }
}