namespace FourMelds.Combat
{
    public enum ModifyMode
    {
        Add,
        Multiply,
        Override
    }
}