namespace FourMelds.Combat
{
    /// <summary>
    /// C# 9.0 ȣȯ: record struct ��� readonly struct ���
    /// </summary>
    public readonly struct TurnIndex
    {
        public int Value { get; }

        public TurnIndex(int value)
        {
            Value = value;
        }

        public override string ToString() => Value.ToString();
    }
}
